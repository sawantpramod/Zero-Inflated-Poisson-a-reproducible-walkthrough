"""
Run all three scripts in order.

Usage:
    python run_all.py           # from repo root
    python scripts/run_all.py   # from repo root
    (also works if run from inside scripts/, or from anywhere else)

Works whether this file lives at the repo root or inside scripts/.
"""

import subprocess
import sys
from pathlib import Path

# Files to run, relative to the scripts/ directory.
SCRIPTS = [
    "01_classroom_zero_gap.py",
    "02_zip_simulation.py",
    "03_zip_model_comparison.py",
]

# --- Figure out where this file is and where scripts/ lives -------------
HERE = Path(__file__).resolve().parent

# If this file is inside scripts/, HERE is scripts/.
# If this file is at the repo root, HERE is the repo root and
# scripts/ is HERE/scripts.
if (HERE / "01_classroom_zero_gap.py").exists():
    SCRIPTS_DIR = HERE                       # run_all.py is inside scripts/
elif (HERE / "scripts" / "01_classroom_zero_gap.py").exists():
    SCRIPTS_DIR = HERE / "scripts"           # run_all.py is at repo root
else:
    raise SystemExit(
        "Could not locate the scripts directory. Expected either\n"
        f"  {HERE / '01_classroom_zero_gap.py'}\n"
        f"or\n"
        f"  {HERE / 'scripts' / '01_classroom_zero_gap.py'}"
    )

# --- Run them in order --------------------------------------------------
for name in SCRIPTS:
    script_path = SCRIPTS_DIR / name
    if not script_path.exists():
        raise SystemExit(f"Missing script: {script_path}")
    print(f"\n=== Running {script_path.relative_to(HERE.parent if SCRIPTS_DIR.name == 'scripts' else HERE)} ===")
    subprocess.run([sys.executable, str(script_path)], check=True)

print("\nAll scripts completed successfully.")