"""
Zero-Inflated Poisson (ZIP) — Part 2: Model comparison
-------------------------------------------------------
Fits Poisson, Zero-Inflated Poisson (ZIP), and Negative Binomial (NB)
to the SAME simulated data from Part 1, and compares them on
log-likelihood, AIC, and BIC.

"""

from pathlib import Path

import numpy as np
import pandas as pd
from statsmodels.discrete.count_model import ZeroInflatedPoisson
from statsmodels.discrete.discrete_model import Poisson, NegativeBinomial

# ----------------------------------------------------------------------
# Locate Part 1's CSV — <repo>/outputs/data/zip_simulated_y.csv
# ----------------------------------------------------------------------
REPO_ROOT = Path(__file__).resolve().parent.parent
CSV_PATH = REPO_ROOT / "outputs" / "data" / "zip_simulated_y.csv"

REGENERATE = False  # set True to regenerate data instead of loading Part 1's file
SEED = 42

# ----------------------------------------------------------------------
# Load (or regenerate) the simulated data
# ----------------------------------------------------------------------
if REGENERATE:
    rng = np.random.default_rng(SEED)
    n, pi_true, lambda_true = 1_000, 0.60, 1.5
    is_structural_zero = rng.random(n) < pi_true
    poisson_draws = rng.poisson(lam=lambda_true, size=n)
    y = np.where(is_structural_zero, 0, poisson_draws)
else:
    if not CSV_PATH.exists():
        raise SystemExit(
            f"Missing {CSV_PATH}.\n"
            f"Run scripts/02_zip_simulation.py first, "
            f"or set REGENERATE = True in this script."
        )
    # skiprows=1 skips the 'y' header row; dtype=int because counts
    y = np.loadtxt(CSV_PATH, delimiter=",", skiprows=1, dtype=int)

n = len(y)
exog = np.ones((n, 1))  # intercept-only for all three models (fair comparison)

# ----------------------------------------------------------------------
# Fit: plain Poisson
# ----------------------------------------------------------------------
poisson_model = Poisson(y, exog).fit(disp=0)

# ----------------------------------------------------------------------
# Fit: Zero-Inflated Poisson
#    exog_infl = predictors for the "structural zero" logit component
#    (intercept-only here, matching the simple fixed-pi/lambda case
#     discussed in the article)
# ----------------------------------------------------------------------
zip_model = ZeroInflatedPoisson(
    y, exog, exog_infl=exog, inflation="logit"
).fit(disp=0)

# ----------------------------------------------------------------------
# Fit: Negative Binomial (handles overdispersion, but has ONE process —
# no separate structural-zero mechanism)
# ----------------------------------------------------------------------
nb_model = NegativeBinomial(y, exog).fit(disp=0)

# ----------------------------------------------------------------------
# Compare on multiple criteria — never rank by a single number alone
# ----------------------------------------------------------------------
results = pd.DataFrame(
    {
        "Model": ["Poisson", "ZIP", "Negative Binomial"],
        "Log-Likelihood": [poisson_model.llf, zip_model.llf, nb_model.llf],
        "AIC": [poisson_model.aic, zip_model.aic, nb_model.aic],
        "BIC": [poisson_model.bic, zip_model.bic, nb_model.bic],
        "Params": [
            poisson_model.params.size,
            zip_model.params.size,
            nb_model.params.size,
        ],
    }
).round(2)

print("=" * 70)
print("MODEL COMPARISON — Poisson vs. ZIP vs. Negative Binomial")
print("=" * 70)
print(results.to_string(index=False))
print("-" * 70)

best_aic = results.loc[results["AIC"].idxmin(), "Model"]
best_bic = results.loc[results["BIC"].idxmin(), "Model"]
print(f"Lowest AIC: {best_aic}   |   Lowest BIC: {best_bic}")
print(
    "\nHow to read this (deliberately cautious phrasing):\n"
    f"'{best_aic} is better supported by AIC on this sample' — not\n"
    "'proven correct.' AIC/BIC compare relative fit under stated\n"
    "assumptions; they don't verify that a structural-zero mechanism\n"
    "actually exists. That case has to be made on domain grounds\n"
    "(is there a real reason some units could never generate a\n"
    "positive count?), with the model comparison as supporting,\n"
    "not sole, evidence."
)

# ----------------------------------------------------------------------
# Inspect the fitted ZIP parameters against the TRUE simulation values
# (only possible here because this is simulated data)
#
# statsmodels orders ZIP params as [inflation params..., count params...]
# with intercept-only exog, that's [inflate_const, count_const]
# ----------------------------------------------------------------------
inflate_const, count_const = zip_model.params
pi_hat = 1 / (1 + np.exp(-inflate_const))     # inverse logit
lambda_hat_zip = np.exp(count_const)

print("\n" + "=" * 70)
print("ZIP recovered parameters vs. true simulation values")
print("=" * 70)
print(f"True pi = 0.60      |  ZIP-estimated pi ≈ {pi_hat:.3f}")
print(f"True lambda = 1.50  |  ZIP-estimated lambda ≈ {lambda_hat_zip:.3f}")
print(
    "\nThis recovery check is a sanity check on the METHOD (does ZIP\n"
    "estimation get back the parameters we put in?), not evidence that\n"
    "any given real-world dataset has a structural-zero process — that\n"
    "still has to be argued from domain knowledge."
)