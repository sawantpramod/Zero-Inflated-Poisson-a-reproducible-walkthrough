"""
Classroom late-arrivals example — observed vs. Poisson-expected
------------------------------------------------------------------
Reproduces the exact numbers used in the article's classroom hook:
100 students, observed frequency table, lambda_hat computed from the
data, and the Poisson(lambda_hat) expected counts for comparison.

No random seed needed — this is a fixed, published dataset (the
classroom table), not a simulation.

Paths are resolved relative to the repository root, so this script
runs unchanged on any machine once the repo is cloned.
"""

from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import poisson

# ----------------------------------------------------------------------
# 0. Output directory — <repo>/figures (created if missing)
# ----------------------------------------------------------------------
REPO_ROOT = Path(__file__).resolve().parent.parent
FIG_DIR = REPO_ROOT / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)

# ----------------------------------------------------------------------
# 1. The classroom frequency table, exactly as stated in the article
# ----------------------------------------------------------------------
counts = np.array([0, 1, 2, 3, 4, 5])
observed_freq = np.array([72, 12, 7, 4, 3, 2])
n = int(observed_freq.sum())
assert n == 100, f"Frequencies should sum to 100, got {n}"

# ----------------------------------------------------------------------
# 2. lambda_hat = sample mean (matches the article's calculation)
# ----------------------------------------------------------------------
lambda_hat = (counts * observed_freq).sum() / n
print(f"n = {n}")
print(f"lambda_hat = {lambda_hat:.2f}")

# ----------------------------------------------------------------------
# 3. Poisson-expected frequencies at lambda_hat
# ----------------------------------------------------------------------
expected_freq = poisson.pmf(counts, mu=lambda_hat) * n

print("\ncount | observed | poisson-expected")
for k, obs, exp in zip(counts, observed_freq, expected_freq):
    print(f"{k:5d} | {obs:8d} | {exp:15.1f}")

gap = observed_freq[0] - expected_freq[0]
print(f"\nZero gap: observed {observed_freq[0]} vs. "
      f"expected {expected_freq[0]:.1f}"
      f"  -> +{gap:.1f} students ({gap:.0f} percentage points)")

# ----------------------------------------------------------------------
# 4. Grouped bar chart
# ----------------------------------------------------------------------
x = np.arange(len(counts))
width = 0.35

fig, ax = plt.subplots(figsize=(8, 5))
ax.bar(x - width / 2, observed_freq, width,
       label="Observed (100 students)", color="#4C72B0")
ax.bar(x + width / 2, expected_freq, width,
       label=f"Poisson-expected (λ̂={lambda_hat:.2f})",
       color="#C44E52", alpha=0.85)

ax.set_xticks(x)
ax.set_xticklabels(counts)
ax.set_xlabel("Number of late arrivals")
ax.set_ylabel("Number of students")
ax.set_title("Late arrivals: observed vs. Poisson-expected\n(100 students)")
ax.legend()

# annotate the zero-count gap directly on the chart
ax.annotate(
    f"+{gap:.0f} more students\nthan Poisson expects",
    xy=(0 + width / 2, expected_freq[0]),
    xytext=(1.1, observed_freq[0] - 5),
    arrowprops=dict(arrowstyle="->", color="black"),
    fontsize=9,
)

fig.tight_layout()

output_path = FIG_DIR / "classroom_zero_gap.png"
fig.savefig(output_path, dpi=150)
print(f"\nSaved plot to {output_path}")