"""
Zero-Inflated Poisson (ZIP) — Part 1: Simulation

"""

from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import poisson

# ----------------------------------------------------------------------
# Output directories — <repo>/outputs/data and <repo>/figures
# ----------------------------------------------------------------------
REPO_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = REPO_ROOT / "outputs" / "data"
FIG_DIR  = REPO_ROOT / "figures"
DATA_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

# ----------------------------------------------------------------------
# Reproducibility
# ----------------------------------------------------------------------
SEED = 42
rng = np.random.default_rng(SEED)

# ----------------------------------------------------------------------
# True (known) data-generating parameters
# ----------------------------------------------------------------------
n = 1_000          # number of observations
pi_true = 0.60     # true probability of being a STRUCTURAL zero
lambda_true = 1.5  # true Poisson rate for the "exposed" group

# ----------------------------------------------------------------------
# Generate ZIP data
#    Step A: decide who is a structural zero (coin flip with prob pi_true)
#    Step B: everyone else draws from Poisson(lambda_true)

# ----------------------------------------------------------------------
is_structural_zero = rng.random(n) < pi_true
poisson_draws = rng.poisson(lam=lambda_true, size=n)
y = np.where(is_structural_zero, 0, poisson_draws)

# ----------------------------------------------------------------------
# Observed vs. naive-Poisson-expected zero percentage
# ----------------------------------------------------------------------
observed_zero_pct = (y == 0).mean() * 100
lambda_hat = y.mean()  # MLE of lambda for a plain Poisson fit
poisson_expected_zero_pct = poisson.pmf(0, mu=lambda_hat) * 100

print("=" * 60)
print("ZIP SIMULATION — SUMMARY")
print("=" * 60)
print(f"Random seed:                            {SEED}")
print(f"n:                                      {n}")
print(f"True pi (structural-zero probability):  {pi_true}")
print(f"True lambda (Poisson rate):             {lambda_true}")
print("-" * 60)
print(f"Sample mean of y (lambda_hat):          {lambda_hat:.3f}")
print(f"Observed zero percentage:               {observed_zero_pct:.1f}%")
print(f"Naive Poisson expected zero percentage: {poisson_expected_zero_pct:.1f}%")
print(f"Gap (observed - naive Poisson):         "
      f"{observed_zero_pct - poisson_expected_zero_pct:.1f} pts")
print("=" * 60)
print(
    "Interpretation (only valid because we simulated this data):\n"
    "The gap above exists because we deliberately mixed in a\n"
    "structural-zero process. On real data, a gap like this is a\n"
    "signal worth investigating, not automatic confirmation of\n"
    "structural zeros — see Part 2 for how far the evidence can\n"
    "honestly be pushed."
)

# ----------------------------------------------------------------------
# Visualize: observed histogram vs. naive Poisson(lambda_hat) fit
# ----------------------------------------------------------------------
max_k = int(y.max())
k_values = np.arange(0, max_k + 1)
poisson_pmf_values = poisson.pmf(k_values, mu=lambda_hat) * n

fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(
    y, bins=np.arange(-0.5, max_k + 1.5, 1),
    color="#4C72B0", alpha=0.75, edgecolor="white",
    label="Observed (simulated ZIP data)",
)
ax.plot(
    k_values, poisson_pmf_values,
    "o--", color="#C44E52",
    label=f"Naive Poisson fit (λ̂={lambda_hat:.2f})",
)
ax.set_xlabel("Count")
ax.set_ylabel("Frequency")
ax.set_title("Observed counts vs. naive Poisson fit\n(the 'mountain of zeros')")
ax.legend()
fig.tight_layout()

png_path = FIG_DIR / "zip_histogram.png"
fig.savefig(png_path, dpi=150)
print(f"\nSaved plot to {png_path}")

# ----------------------------------------------------------------------
# Save the simulated data as a real CSV (for Part 2 to reuse)
# ----------------------------------------------------------------------
csv_path = DATA_DIR / "zip_simulated_y.csv"
np.savetxt(csv_path, y, fmt="%d", delimiter=",", header="y", comments="")
print(f"Saved simulated data to {csv_path}")